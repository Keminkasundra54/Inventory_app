import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';
import { AuthGuard } from '../guard/auth/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: HomePage,
    children: [
      {
        path: '',
        redirectTo: 'products',
        pathMatch: 'full'
      },
      {
        path: 'products',
        loadChildren: () => import('./pages/products/products.module').then(m => m.ProductsPageModule)
      },
      {
        path: 'product-details/:id',
        loadChildren: () => import('./pages/product-details/product-details.module').then(m => m.ProductDetailsPageModule)
      },
      {
        path: 'cart',
        loadChildren: () => import('./pages/cart/cart.module').then(m => m.CartPageModule),
        canActivate: [AuthGuard]
      },
      {
        path: 'wishlist',
        loadChildren: () => import('./pages/wishlist/wishlist.module').then(m => m.WishlistPageModule),
        canActivate: [AuthGuard]

      },
      {
        path: 'checkout',
        loadChildren: () => import('./pages/checkout/checkout.module').then(m => m.CheckoutPageModule),
        canActivate: [AuthGuard]
      },
      {
        path: 'profile',
        loadChildren: () => import('./pages/profile/profile.module').then(m => m.ProfilePageModule),
        canActivate: [AuthGuard]
      },
      {
        path: 'status',
        loadChildren: () => import('./pages/status/status.module').then(m => m.StatusPageModule),
        canActivate: [AuthGuard]
      },
      {
        path: 'status-details/:id',
        loadChildren: () => import('./pages/status-details/status-details.module').then( m => m.StatusDetailsPageModule),
        canActivate: [AuthGuard]
      },
    ]
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./pages/signup/signup.module').then(m => m.SignupPageModule)
  },
  {
    path: 'forget-password',
    loadChildren: () => import('./pages/forget-password/forget-password.module').then(m => m.ForgetPasswordPageModule)
  },
  {
    path: 'reset-password/:token/:email',
    loadChildren: () => import('./pages/reset-password/reset-password.module').then(m => m.ResetPasswordPageModule)
  },

 





  // {
  //   path: 'products/:id',
  //   component:ProductsComponent
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomePageRoutingModule { }
