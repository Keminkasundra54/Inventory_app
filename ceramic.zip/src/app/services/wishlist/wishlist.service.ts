import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {

  url = environment.url
  constructor(private http: HttpClient, private router: Router) { }

  getWishList(id:any){
    let url = this.url + 'getUserWishlist'

    return this.http.post(url,id, { observe: 'response' })
  }
  addWishList(id:any){

    let url = this.url + 'addWishlist'

    return this.http.post(url,id, { observe: 'response' })
  }
  removeWishList(id:any){

    let url = this.url + 'removeWishlist'

    return this.http.post(url,id, { observe: 'response' })
  }
}
