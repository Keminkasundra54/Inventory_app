import { HttpClient } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  url = environment.url
  token: any
  userData = signal('')
  constructor(private http: HttpClient, private router: Router) { }
  signup(data: any) {
    let url = this.url + 'register'

    return this.http.post(url, data, { observe: 'response' })
  }
  login(data: any) {
    let url = this.url + 'login'

    return this.http.post(url, data, { observe: 'response' })
  }
  forgotPassword(data: any) {
    let url = this.url + 'frgtpassword'

    return this.http.post(url, data, { observe: 'response' })
  }
  resetPassword(data: any) {
    let url = this.url + 'resetpass'

    return this.http.post(url, data, { observe: 'response' })
  }
  isLoggedIn() {
    if (localStorage.getItem('userData')) {

      this.userData.set(JSON.parse(localStorage.getItem('userData')!))
      console.log(this.userData());
      
      this.router.navigate(['']);

    }
  }
  emailConfirmation(key: any) {
    let url = this.url + 'activate'
    return this.http.post(url, key, { observe: 'response' })
  }
  getToken() {
    if (localStorage.getItem('userData')) {
      return (JSON.parse(localStorage.getItem('userData')!)).token
    } else {
      this.router.navigate(['']);
    }
  }
}
