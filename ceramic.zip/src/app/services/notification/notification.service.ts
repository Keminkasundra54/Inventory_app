import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  url = environment.url
  constructor(private http: HttpClient) { }

  getUserNotification(data: any) {
    let url = this.url + 'getUserNotification'

    return this.http.post(url, data, { observe: 'response' })
  }

  updateNoti(data:any){
    let url = this.url + 'updateNotification'

    return this.http.post(url, data, { observe: 'response' })
  }
  delete(data:any){
    let url = this.url + 'RemoveNotification'

    return this.http.post(url, data, { observe: 'response' })
  }
}
