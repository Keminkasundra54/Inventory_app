import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PromocodeService {

  url = environment.url
  constructor(private http: HttpClient, private router: Router) { }

  getPromoCodes() {
    let url = this.url + 'getPromoCodes'

    return this.http.get(url, { observe: 'response' })
  }
  getPromoCode(data: any) {
    let url = this.url + 'getUserWishlist'

    return this.http.post(url, data, { observe: 'response' })
  }
  searchPromoCode(data:any){
    let url = this.url + 'searchPromoCode'

    return this.http.post(url, data, { observe: 'response' })
  }
  addPromoCode(id: any) {

    let url = this.url + 'addPromoCode'

    return this.http.post(url, id, { observe: 'response' })
  }
  edit(id: any) {

    let url = this.url + 'getOnePromoCode'

    return this.http.post(url, id, { observe: 'response' })
  }
  upate(id: any) {

    let url = this.url + 'updatePromoCode'

    return this.http.post(url, id, { observe: 'response' })
  }

  removePromoCode(id: any) {

    let url = this.url + 'removePromoCode'

    return this.http.post(url, id, { observe: 'response' })
  }
}
