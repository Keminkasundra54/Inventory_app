import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { environment } from 'src/environments/environment';
function _window(): any {

  // return the global native browser window object

  return window;

}
@Injectable({
  providedIn: 'root'
})
export class OrderService {
  url = environment.url
  constructor(private http: HttpClient, @Inject(PLATFORM_ID) private platformId: object) { }

  get nativeWindow(): any {

    if (isPlatformBrowser(this.platformId)) {

      return _window();

    }

  }
  createRpOrder(data: any) {
    let url = this.url + 'createOrderInRp'

    return this.http.post(url, data, { observe: 'response' })
  }

  addOrder(data: any) {
    let url = this.url + 'addOrder'

    return this.http.post(url, data, { observe: 'response' })
  }


  orderStatus(data: any) {
    let url = this.url + 'getUserOrderStatus'

    return this.http.post(url, data, { observe: 'response' })
  }

  getOrder(id: any) {

    let url = this.url + 'getOneOrder'

    return this.http.post(url, id, { observe: 'response' })
  }

  cancelOrder(id: any) {
    let url = this.url + 'cancelOrder'

    return this.http.post(url, id, { observe: 'response' })
  }
  // addAddress(data: any) {
  //   let url = this.url + 'addAddress'

  //   return this.http.post(url, data, { observe: 'response' })
  // }
}
