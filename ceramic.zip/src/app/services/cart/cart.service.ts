import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  url = environment.url
  constructor(private http: HttpClient) { }

  getCart(id: any) {
    let url = this.url + 'getUserCart '

    return this.http.post(url, id, { observe: 'response' })
  }
  addToCart(data: any) {
    let url = this.url + 'addCart'

    return this.http.post(url, data, { observe: 'response' })
  }
  updateCart(data: any) {
    let url = this.url + 'updateCartQuantity '

    return this.http.post(url, data, { observe: 'response' })
  }
  removeCart(data: any) {

    let url = this.url + 'removeProductFromCart '

    return this.http.post(url, data, { observe: 'response' })
  }
}
