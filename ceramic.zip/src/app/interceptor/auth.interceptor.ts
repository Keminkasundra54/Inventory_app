import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, delay, finalize } from 'rxjs';
import { AuthService } from '../services/auth/auth.service';
import { LoaderService } from '../services/loader/loader.service';
import { environment } from 'src/environments/environment';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private auth: AuthService, private loader: LoaderService) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const token = this.auth.getToken();
    console.log(token);

    if (token) {
      console.log('yess token done ', request);

      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
          token: `${token}`,
          'x-access-token': token,
          storeId:environment.store1
        }
      });
    }
    this.loader.showLoader();

    // return next.handle(request);

    return next.handle(request).pipe(
      delay(1000),
      finalize(() => {
        this.loader.hideLoader();

      })
    );
  }
}
