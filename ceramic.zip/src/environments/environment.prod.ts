export const environment = {
  production: true,
  // url:'https://192.168.1.13:8080/',
  url:'http://192.168.1.9:443/',
  razorPayKey: 'rzp_test_laztbIrkPBiRRS',
  enablePaymentGateway: true,
  store:'66050296333114bb4f5081f6',
  store1:'65f27f61b5a90c05abc48e9f',
};
