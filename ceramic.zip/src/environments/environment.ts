// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // url:'https://192.168.1.13:8080/',
  url:'http://192.168.1.12:443/',
  razorPayKey: 'rzp_test_laztbIrkPBiRRS',
  enablePaymentGateway: true,
  store:'66050296333114bb4f5081f6',
  store1:'65f27f61b5a90c05abc48e9f',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
